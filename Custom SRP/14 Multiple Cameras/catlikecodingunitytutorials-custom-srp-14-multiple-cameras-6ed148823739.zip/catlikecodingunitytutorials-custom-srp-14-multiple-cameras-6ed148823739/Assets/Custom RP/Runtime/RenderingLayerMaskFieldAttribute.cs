﻿using UnityEngine;

public class RenderingLayerMaskFieldAttribute : PropertyAttribute {}