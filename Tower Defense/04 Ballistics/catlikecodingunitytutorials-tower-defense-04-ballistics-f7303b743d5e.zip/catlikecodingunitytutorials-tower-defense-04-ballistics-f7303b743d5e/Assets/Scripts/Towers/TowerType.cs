﻿public enum TowerType {
	Laser, Mortar
}