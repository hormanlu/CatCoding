﻿public enum EnemyType {
	Small, Medium, Large
}