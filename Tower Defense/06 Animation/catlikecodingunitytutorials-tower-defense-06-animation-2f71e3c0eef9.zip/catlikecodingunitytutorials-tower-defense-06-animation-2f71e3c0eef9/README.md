# Tower Defense 06: Animation

[This is the sixth and last installment of a tutorial series about creating a simple tower defense game.](https://catlikecoding.com/unity/tutorials/tower-defense/animation/) It is about animating enemies, covering both recording new animations and importing existing assets.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)