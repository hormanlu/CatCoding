# Tower Defense 02: Enemies

[This is the second installment of a tutorial series about creating a simple tower defense game.](https://catlikecoding.com/unity/tutorials/tower-defense/enemies/) It covers spawning enemies and moving them to the nearest destination.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)