# Tower Defense 03: Towers

[This is the third installment of a tutorial series about creating a simple tower defense game.](https://catlikecoding.com/unity/tutorials/tower-defense/towers/) It covers the creations of towers and how they target and shoot enemies.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)