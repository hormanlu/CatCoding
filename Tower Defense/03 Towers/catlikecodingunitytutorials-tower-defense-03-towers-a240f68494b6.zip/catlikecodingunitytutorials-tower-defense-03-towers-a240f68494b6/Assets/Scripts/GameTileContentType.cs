﻿public enum GameTileContentType {
	Empty, Destination, Wall, SpawnPoint, Tower
}