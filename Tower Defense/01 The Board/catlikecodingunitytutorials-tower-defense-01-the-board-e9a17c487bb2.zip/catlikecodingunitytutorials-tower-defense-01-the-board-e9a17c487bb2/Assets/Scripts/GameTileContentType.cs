﻿public enum GameTileContentType {
	Empty, Destination, Wall
}