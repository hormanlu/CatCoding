# Tower Defense 01: The Board

[This is the first installment of a tutorial series about creating a simple tower defense game.](https://catlikecoding.com/unity/tutorials/tower-defense/the-board/) It covers the creation of the game board, pathfinding, and placement of destinations and walls.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)