# Object Management 11: Lifecycle

[This is the eleventh tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/lifecycle/) It introduces more fluid shape creation and destruction, by adding behavior for growing and dying.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)