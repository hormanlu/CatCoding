# Object Management 05: Spawn Zones

[This is the fifth tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/spawn-zones/) It's about making objects spawn in more varied patterns, configurable per level.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)