# Object Management 07: Configuring Shapes

[This is the seventh tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/configuring-shapes/) It adds some behavior to shapes and makes it possible to configure them, per spawn zone.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)