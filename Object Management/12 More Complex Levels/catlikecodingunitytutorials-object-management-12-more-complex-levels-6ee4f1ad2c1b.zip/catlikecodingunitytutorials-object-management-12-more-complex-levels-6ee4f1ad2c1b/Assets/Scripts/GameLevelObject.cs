﻿public class GameLevelObject : PersistableObject {

	public virtual void GameUpdate () {}
}