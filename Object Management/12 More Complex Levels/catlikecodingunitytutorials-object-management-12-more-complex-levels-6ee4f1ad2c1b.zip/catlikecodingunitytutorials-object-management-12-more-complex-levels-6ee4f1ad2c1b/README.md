# Object Management 12: More Complex Levels

[This is the twelfth and final tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/more-complex-levels/) It covers the addition of kill zones and more strict management of level objects.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)