# Object Management 08: More Factories

[This is the eighth tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/more-factories/) It introduces the concept of working with more than one factory, along with more complex shapes.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)