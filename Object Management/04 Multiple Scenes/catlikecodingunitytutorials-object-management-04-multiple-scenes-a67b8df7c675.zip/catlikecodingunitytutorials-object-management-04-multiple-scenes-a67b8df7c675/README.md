# Object Management 04: Multiple Scenes

[This is the fourth tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/multiple-scenes/) It's about putting objects in their own scene, working with multiple scenes at once, plus loading and unloading scenes.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)