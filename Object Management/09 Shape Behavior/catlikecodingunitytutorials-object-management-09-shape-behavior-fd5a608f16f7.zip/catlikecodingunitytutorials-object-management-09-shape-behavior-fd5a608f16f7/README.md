# Object Management 09: Shape Behavior

[This is the ninth tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/shape-behavior/) It adds support for modular behavior to shapes.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)