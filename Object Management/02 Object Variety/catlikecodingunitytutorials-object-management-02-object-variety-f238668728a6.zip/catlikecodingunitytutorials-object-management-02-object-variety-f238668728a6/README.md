# Object Management 02: Object Variety

[This is the second tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/object-variety/) In this part we'll add support for multiple shapes with varying materials and colors, while remaining backwards compatible with the previous version of our game.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)