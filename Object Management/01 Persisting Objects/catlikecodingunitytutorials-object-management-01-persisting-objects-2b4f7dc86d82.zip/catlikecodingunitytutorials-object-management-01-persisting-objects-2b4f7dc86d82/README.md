# Object Management 01: Persisting Objects

[This is the first tutorial in a series about managing objects.](https://catlikecoding.com/unity/tutorials/object-management/persisting-objects/) It covers creating, tracking, saving, and loading simple prefab instances. It builds on the foundation laid by the tutorials in the Basics section.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)