# Object Management 03: Reusing Objects

[This is the third tutorial in a series about Object Management.](https://catlikecoding.com/unity/tutorials/object-management/reusing-objects/) It adds the ability to destroy shapes, followed by a way to reuse them.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)