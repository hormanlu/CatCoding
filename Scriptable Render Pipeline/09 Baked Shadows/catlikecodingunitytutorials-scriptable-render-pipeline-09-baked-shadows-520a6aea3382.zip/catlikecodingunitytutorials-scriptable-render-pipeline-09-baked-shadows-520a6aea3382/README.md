# Scriptable Render Pipeline 09: Baked Shadows

[This is the ninth installment of a tutorial series covering Unity's scriptable render pipeline.](https://catlikecoding.com/unity/tutorials/scriptable-render-pipeline/baked-shadows/) It's about combining realtime lighting with baked shadows, and baked lighting with realtime shadows in the case of subtractive lighting.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)