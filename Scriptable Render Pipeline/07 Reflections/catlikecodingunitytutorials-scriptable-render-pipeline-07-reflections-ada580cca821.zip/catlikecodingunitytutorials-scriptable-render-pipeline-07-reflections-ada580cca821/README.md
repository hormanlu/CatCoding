# Scriptable Render Pipeline 07: Reflections

[This is the seventh installment of a tutorial series covering Unity's scriptable render pipeline.](https://catlikecoding.com/unity/tutorials/scriptable-render-pipeline/reflections/) It covers the addition of reflections, both specular highlights and sampled reflection probes.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)