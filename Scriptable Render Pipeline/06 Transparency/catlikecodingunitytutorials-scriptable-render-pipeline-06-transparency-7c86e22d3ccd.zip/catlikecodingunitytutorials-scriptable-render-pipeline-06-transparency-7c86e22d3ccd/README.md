# Scriptable Render Pipeline 06: Transparency

[This is the sixth installment of a tutorial series covering Unity's scriptable render pipeline.](https://catlikecoding.com/unity/tutorials/scriptable-render-pipeline/transparency/) It's about adding support for alpha clipping and semi-transparent materials.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)