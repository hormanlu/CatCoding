# Scriptable Render Pipeline 02: Custom Shaders

[This is the second installment of a tutorial series covering Unity's scriptable render pipeline.](https://catlikecoding.com/unity/tutorials/scriptable-render-pipeline/custom-shaders/) It's about creating a shader using HLSL and efficiently rendering multiple objects by batching them in a single draw call.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)