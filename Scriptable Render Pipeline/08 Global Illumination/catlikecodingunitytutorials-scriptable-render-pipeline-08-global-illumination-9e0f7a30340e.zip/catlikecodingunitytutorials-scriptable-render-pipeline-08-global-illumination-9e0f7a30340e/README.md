# Scriptable Render Pipeline 08: Global Illumination

[This is the eighth installment of a tutorial series covering Unity's scriptable render pipeline.](https://catlikecoding.com/unity/tutorials/scriptable-render-pipeline/global-illumination/) It's about supporting both static and dynamic global illumination.

## License

You can do whatever you want with the files in this project. I offer neither guarantees nor warranties. If you use the files, then you're liable for them. It would be nice if you gave me credit.

## Author

[Jasper Flick](https://catlikecoding.com/jasper-flick/)